class CustomDialogChart extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.numbersY = [12, 25, 50, 34.00, 90, 80, 94];
        this.numX = 0;
        this.controller = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.numbersY !== undefined) {
            this.numbersY = params.numbersY;
        }
        if (params.numX !== undefined) {
            this.numX = params.numX;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    setController(ctr) {
        this.controller = ctr;
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("views/item/ItemChart.ets(11:5)");
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //绘制折线图
            Polyline.create({ width: 200, height: 200 });
            Polyline.debugLine("views/item/ItemChart.ets(13:7)");
            //绘制折线图
            Polyline.points(this.parseArr(this.numX, this.numbersY));
            //绘制折线图
            Polyline.fillOpacity(0);
            //绘制折线图
            Polyline.stroke(Color.Black);
            //绘制折线图
            Polyline.strokeWidth(2);
            if (!isInitialRender) {
                //绘制折线图
                Polyline.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('关闭');
            Button.debugLine("views/item/ItemChart.ets(21:7)");
            Button.onClick(() => {
                this.controller.close();
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    parseArr(numX, numbers) {
        let arr = [];
        numbers.forEach((num) => {
            arr.push([numX += 40, num]);
        });
        return arr;
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Column__ColumnStyle() {
    Column.width(100);
    Column.height(100);
    Column.borderRadius(5);
    Column.shadow({ radius: 5, color: '#CCCCCC', offsetX: 5, offsetY: 5 });
    Column.backgroundColor(Color.White);
    Column.justifyContent(FlexAlign.Center);
}
export default class ItemChart extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.controller = new CustomDialogController({
            builder: () => {
                let jsDialog = new CustomDialogChart(this, {});
                jsDialog.setController(this.
                //开启弹窗
                controller);
                ViewPU.create(jsDialog);
            }
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 10 });
            Row.debugLine("views/item/ItemChart.ets(59:5)");
            Row.margin({ top: 20, bottom: 20 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //1.图表展示本月支出消费
            Column.create({ space: 5 });
            Column.debugLine("views/item/ItemChart.ets(61:7)");
            __Column__ColumnStyle();
            //1.图表展示本月支出消费
            Column.onClick(() => {
                //展示图表的信息
                this.controller.open();
            });
            if (!isInitialRender) {
                //1.图表展示本月支出消费
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777239, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Image.debugLine("views/item/ItemChart.ets(62:9)");
            Image.width(30);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777227, "type": 10003, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Text.debugLine("views/item/ItemChart.ets(64:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //1.图表展示本月支出消费
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //2.历史账单记录
            Column.create({ space: 5 });
            Column.debugLine("views/item/ItemChart.ets(73:7)");
            __Column__ColumnStyle();
            //2.历史账单记录
            Column.onClick(() => {
            });
            if (!isInitialRender) {
                //2.历史账单记录
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Image.debugLine("views/item/ItemChart.ets(74:9)");
            Image.width(30);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777225, "type": 10003, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Text.debugLine("views/item/ItemChart.ets(76:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //2.历史账单记录
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //3.预算剩余
            Column.create({ space: 5 });
            Column.debugLine("views/item/ItemChart.ets(84:7)");
            __Column__ColumnStyle();
            if (!isInitialRender) {
                //3.预算剩余
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Image.debugLine("views/item/ItemChart.ets(85:9)");
            Image.width(30);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777226, "type": 10003, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Text.debugLine("views/item/ItemChart.ets(87:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //3.预算剩余
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "ItemChart", new ItemChart(undefined, {}));
}
//# sourceMappingURL=ItemChart.js.map