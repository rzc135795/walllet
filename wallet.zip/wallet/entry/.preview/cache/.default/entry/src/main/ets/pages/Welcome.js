"use strict";
class Welcome extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Welcome.ets(7:5)");
            Row.height('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Welcome.ets(8:7)");
            Column.justifyContent(FlexAlign.Center);
            Column.backgroundColor({ "id": 16777227, "type": 10001, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 记账APP的logo
        this.logo.bind(this)();
        // 欢迎页面的提示语句
        this.prompt.bind(this)();
        Column.pop();
        Row.pop();
    }
    logo(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/Welcome.ets(24:5)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 背景
            Stack.create();
            Stack.debugLine("pages/Welcome.ets(26:7)");
            if (!isInitialRender) {
                // 背景
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Circle.create({ width: 230, height: 230 });
            Circle.debugLine("pages/Welcome.ets(27:9)");
            Circle.fill({ "id": 16777228, "type": 10001, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Circle.clip(new Circle({ width: '100%', height: '100%' }));
            Circle.shadow({ radius: 20 });
            if (!isInitialRender) {
                Circle.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Circle.create({ width: 220, height: 220 });
            Circle.debugLine("pages/Welcome.ets(33:9)");
            Circle.fill({ "id": 16777226, "type": 10001, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            if (!isInitialRender) {
                Circle.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 背景
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Welcome.ets(37:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 名字
            Row.create();
            Row.debugLine("pages/Welcome.ets(39:9)");
            if (!isInitialRender) {
                // 名字
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777217, "type": 10003, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Text.debugLine("pages/Welcome.ets(40:11)");
            Text.fontSize(70);
            Text.fontColor({ "id": 16777228, "type": 10001, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        // 名字
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // app图片
            Row.create();
            Row.debugLine("pages/Welcome.ets(45:9)");
            if (!isInitialRender) {
                // app图片
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Image.debugLine("pages/Welcome.ets(46:11)");
            Image.width(100);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // app图片
        Row.pop();
        Column.pop();
        Stack.pop();
    }
    prompt(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Welcome.ets(53:5)");
            Column.padding({ bottom: 10 });
            Column.position({ y: '100%', x: '50%' });
            Column.translate({ y: '-100%', x: '-50%' });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('本应用用于帮助用户快速记账  不会动用您的财产');
            Text.debugLine("pages/Welcome.ets(54:7)");
            __Text__promptText();
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('应用不会使用到网络权限  不会查看您的隐私');
            Text.debugLine("pages/Welcome.ets(56:7)");
            __Text__promptText();
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('保证无广告  且永久免费');
            Text.debugLine("pages/Welcome.ets(58:7)");
            __Text__promptText();
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Text__promptText() {
    Text.fontSize(12);
    Text.fontColor(Color.White);
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Welcome(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Welcome.js.map