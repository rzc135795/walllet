import ItemBudget from '@bundle:com.example.tallyapplication/entry/ets/views/item/ItemBudget';
import ItemChart from '@bundle:com.example.tallyapplication/entry/ets/views/item/ItemChart';
import ItemList from '@bundle:com.example.tallyapplication/entry/ets/views/item/ItemList';
import ItemShow from '@bundle:com.example.tallyapplication/entry/ets/views/item/ItemShow';
import NumberKeyboard from '@bundle:com.example.tallyapplication/entry/ets/views/item/NumberKeyboard';
import ItemConsumeType from '@bundle:com.example.tallyapplication/entry/ets/views/item/ItemConsumeType';
import ItemBudgetAndIncome from '@bundle:com.example.tallyapplication/entry/ets/views/item/ItemBudgetAndIncome';
class ItemIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__showPanel = new ObservedPropertySimplePU(false
        //收入支出类型选择
        , this, "showPanel");
        this.__isIncome = new ObservedPropertySimplePU(true, this, "isIncome");
        this.__amount = new ObservedPropertySimplePU(0, this, "amount");
        this.__value = new ObservedPropertySimplePU('', this, "value");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.showPanel !== undefined) {
            this.showPanel = params.showPanel;
        }
        if (params.isIncome !== undefined) {
            this.isIncome = params.isIncome;
        }
        if (params.amount !== undefined) {
            this.amount = params.amount;
        }
        if (params.value !== undefined) {
            this.value = params.value;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__showPanel.purgeDependencyOnElmtId(rmElmtId);
        this.__isIncome.purgeDependencyOnElmtId(rmElmtId);
        this.__amount.purgeDependencyOnElmtId(rmElmtId);
        this.__value.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__showPanel.aboutToBeDeleted();
        this.__isIncome.aboutToBeDeleted();
        this.__amount.aboutToBeDeleted();
        this.__value.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get showPanel() {
        return this.__showPanel.get();
    }
    set showPanel(newValue) {
        this.__showPanel.set(newValue);
    }
    get isIncome() {
        return this.__isIncome.get();
    }
    set isIncome(newValue) {
        this.__isIncome.set(newValue);
    }
    get amount() {
        return this.__amount.get();
    }
    set amount(newValue) {
        this.__amount.set(newValue);
    }
    get value() {
        return this.__value.get();
    }
    set value(newValue) {
        this.__value.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/ItemIndex.ets(22:5)");
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("pages/ItemIndex.ets(23:7)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#fff1f1f1');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //1.返回按钮展示
        this.Header.bind(this)();
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    //2.顶部剩余预算展示
                    ItemShow(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    //3.图表、账单、预算入口按钮
                    ItemChart(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    //4.展示本月所有收入和支出
                    ItemBudget(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            __Common__.create();
            __Common__.layoutWeight(1);
            if (!isInitialRender) {
                __Common__.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    //5.本月消费记录列表
                    ItemList(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        __Common__.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //记录面板
            Panel.create(this.showPanel);
            Panel.debugLine("pages/ItemIndex.ets(46:7)");
            //记录面板
            Panel.mode(PanelMode.Full);
            //记录面板
            Panel.dragBar(true);
            //记录面板
            Panel.backgroundMask('#b5b5b7');
            //记录面板
            Panel.backgroundColor(Color.White);
            if (!isInitialRender) {
                //记录面板
                Panel.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //1.消费描述
        this.consumeDescribe.bind(this)();
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    //2.金额及类型
                    ItemConsumeType(this, { amount: this.amount }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        amount: this.amount
                    });
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    //3.选择收入还是支出类型
                    ItemBudgetAndIncome(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    //4.输入面板
                    NumberKeyboard(this, { amount: this.__amount, value: this.__value }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        //5.按钮
        this.PanelButton.bind(this)();
        //记录面板
        Panel.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777237, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Image.debugLine("pages/ItemIndex.ets(69:7)");
            Image.fillColor({ "id": 16777245, "type": 10001, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Image.width(70);
            Image.position({ x: 260, y: 700 });
            Image.onClick(() => {
                //点击后跳转
                this.showPanel = true;
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Stack.pop();
    }
    consumeDescribe(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/ItemIndex.ets(82:5)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('消费描述:');
            Text.debugLine("pages/ItemIndex.ets(83:7)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '消费描述' });
            TextInput.debugLine("pages/ItemIndex.ets(85:7)");
            TextInput.maxLength(20);
            TextInput.type(InputType.Normal);
            TextInput.width(250);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
    }
    PanelButton(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 10 });
            Row.debugLine("pages/ItemIndex.ets(93:5)");
            Row.width('100%');
            Row.margin(20);
            Row.justifyContent(FlexAlign.SpaceEvenly);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('取消');
            Button.debugLine("pages/ItemIndex.ets(94:7)");
            Button.backgroundColor(Color.Gray);
            Button.onClick(() => {
                this.showPanel = false;
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('确认');
            Button.debugLine("pages/ItemIndex.ets(99:7)");
            Button.onClick(() => {
                this.showPanel = false;
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
    }
    Header(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/ItemIndex.ets(110:5)");
            Row.width('90%');
            Row.margin(5);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777218, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Image.debugLine("pages/ItemIndex.ets(111:7)");
            Image.width(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/ItemIndex.ets(114:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('财务管理页面');
            Text.debugLine("pages/ItemIndex.ets(116:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new ItemIndex(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=ItemIndex.js.map