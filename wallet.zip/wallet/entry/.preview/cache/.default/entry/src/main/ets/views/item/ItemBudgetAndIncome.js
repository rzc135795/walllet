import Prompt from '@ohos:prompt';
export default class ItemBudgetAndIncome extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__isIncome = new SynchedPropertySimpleOneWayPU(params.isIncome, this, "isIncome");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.isIncome !== undefined) {
            this.__isIncome.set(params.isIncome);
        }
        else {
            this.__isIncome.set(true);
        }
    }
    updateStateVars(params) {
        this.__isIncome.reset(params.isIncome);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isIncome.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isIncome.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get isIncome() {
        return this.__isIncome.get();
    }
    set isIncome(newValue) {
        this.__isIncome.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("views/item/ItemBudgetAndIncome.ets(9:5)");
            Row.width(200);
            Row.height(50);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 5 });
            Column.debugLine("views/item/ItemBudgetAndIncome.ets(10:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Radio.create({ value: '收入', group: 'radioGroup' });
            Radio.debugLine("views/item/ItemBudgetAndIncome.ets(11:9)");
            Radio.checked(true);
            Radio.height(30);
            Radio.width(30);
            Radio.onChange((value) => {
                //选择类型
                this.isIncome = true;
                Prompt.showToast({
                    message: this.isIncome.toString() + '收入',
                });
            });
            if (!isInitialRender) {
                Radio.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('收入');
            Text.debugLine("views/item/ItemBudgetAndIncome.ets(22:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("views/item/ItemBudgetAndIncome.ets(24:7)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 5 });
            Column.debugLine("views/item/ItemBudgetAndIncome.ets(25:7)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Radio.create({ value: '支出', group: 'radioGroup' });
            Radio.debugLine("views/item/ItemBudgetAndIncome.ets(26:9)");
            Radio.checked(false);
            Radio.height(30);
            Radio.width(30);
            Radio.onChange((value) => {
                //选择类型
                this.isIncome = false;
                Prompt.showToast({
                    message: this.isIncome.toString() + '支出',
                });
            });
            if (!isInitialRender) {
                Radio.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('支出');
            Text.debugLine("views/item/ItemBudgetAndIncome.ets(37:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=ItemBudgetAndIncome.js.map