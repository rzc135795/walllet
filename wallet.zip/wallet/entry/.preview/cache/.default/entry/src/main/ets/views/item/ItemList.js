export default class ItemList extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("views/item/ItemList.ets(4:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777224, "type": 10003, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Text.debugLine("views/item/ItemList.ets(5:7)");
            Text.fontWeight(FontWeight.Bold);
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("views/item/ItemList.ets(9:7)");
            List.height('100%');
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("views/item/ItemList.ets(11:11)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create({ space: 10 });
                            Row.debugLine("views/item/ItemList.ets(12:13)");
                            Row.backgroundColor(Color.White);
                            Row.borderRadius(15);
                            Row.width('100%');
                            Row.padding(10);
                            Row.margin(5);
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //日期
                            Column.create();
                            Column.debugLine("views/item/ItemList.ets(14:15)");
                            if (!isInitialRender) {
                                //日期
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //月
                            Text.create('05月');
                            Text.debugLine("views/item/ItemList.ets(16:17)");
                            if (!isInitialRender) {
                                //月
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //月
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //日
                            Text.create('05日');
                            Text.debugLine("views/item/ItemList.ets(18:17)");
                            if (!isInitialRender) {
                                //日
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //日
                        Text.pop();
                        //日期
                        Column.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //支出类型图片,此处可换成不同颜色显示，对应颜色字段
                            Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
                            Image.debugLine("views/item/ItemList.ets(21:15)");
                            //支出类型图片,此处可换成不同颜色显示，对应颜色字段
                            Image.width(25);
                            if (!isInitialRender) {
                                //支出类型图片,此处可换成不同颜色显示，对应颜色字段
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //支出类型
                            Text.create('水电');
                            Text.debugLine("views/item/ItemList.ets(24:15)");
                            if (!isInitialRender) {
                                //支出类型
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //支出类型
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Blank.create();
                            Blank.debugLine("views/item/ItemList.ets(25:15)");
                            if (!isInitialRender) {
                                Blank.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Blank.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //金额
                            Text.create('-100');
                            Text.debugLine("views/item/ItemList.ets(27:15)");
                            if (!isInitialRender) {
                                //金额
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //金额
                        Text.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create({ space: 10 });
                            Row.debugLine("views/item/ItemList.ets(12:13)");
                            Row.backgroundColor(Color.White);
                            Row.borderRadius(15);
                            Row.width('100%');
                            Row.padding(10);
                            Row.margin(5);
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //日期
                            Column.create();
                            Column.debugLine("views/item/ItemList.ets(14:15)");
                            if (!isInitialRender) {
                                //日期
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //月
                            Text.create('05月');
                            Text.debugLine("views/item/ItemList.ets(16:17)");
                            if (!isInitialRender) {
                                //月
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //月
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //日
                            Text.create('05日');
                            Text.debugLine("views/item/ItemList.ets(18:17)");
                            if (!isInitialRender) {
                                //日
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //日
                        Text.pop();
                        //日期
                        Column.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //支出类型图片,此处可换成不同颜色显示，对应颜色字段
                            Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
                            Image.debugLine("views/item/ItemList.ets(21:15)");
                            //支出类型图片,此处可换成不同颜色显示，对应颜色字段
                            Image.width(25);
                            if (!isInitialRender) {
                                //支出类型图片,此处可换成不同颜色显示，对应颜色字段
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //支出类型
                            Text.create('水电');
                            Text.debugLine("views/item/ItemList.ets(24:15)");
                            if (!isInitialRender) {
                                //支出类型
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //支出类型
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Blank.create();
                            Blank.debugLine("views/item/ItemList.ets(25:15)");
                            if (!isInitialRender) {
                                Blank.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Blank.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            //金额
                            Text.create('-100');
                            Text.debugLine("views/item/ItemList.ets(27:15)");
                            if (!isInitialRender) {
                                //金额
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        //金额
                        Text.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, [1, 2, 3, 4, 5, 6, 7, 8, 9], forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=ItemList.js.map