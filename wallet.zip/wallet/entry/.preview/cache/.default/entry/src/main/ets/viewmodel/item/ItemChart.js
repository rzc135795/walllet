function __Column__ColumnStyle() {
    Column.width(100);
    Column.height(100);
    Column.borderRadius(5);
    Column.shadow({ radius: 5, color: '#CCCCCC', offsetX: 5, offsetY: 5 });
    Column.backgroundColor(Color.White);
    Column.justifyContent(FlexAlign.Center);
}
export default class ItemChart extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 10 });
            Row.debugLine("viewmodel/item/ItemChart.ets(14:5)");
            Row.margin({ top: 20, bottom: 20 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //1.图表展示本月支出消费
            Column.create({ space: 5 });
            Column.debugLine("viewmodel/item/ItemChart.ets(16:7)");
            __Column__ColumnStyle();
            //1.图表展示本月支出消费
            Column.onClick(() => {
                //展示图表的信息
            });
            if (!isInitialRender) {
                //1.图表展示本月支出消费
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777239, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Image.debugLine("viewmodel/item/ItemChart.ets(17:9)");
            Image.width(30);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777227, "type": 10003, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Text.debugLine("viewmodel/item/ItemChart.ets(19:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //1.图表展示本月支出消费
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //2.历史账单记录
            Column.create({ space: 5 });
            Column.debugLine("viewmodel/item/ItemChart.ets(27:7)");
            __Column__ColumnStyle();
            //2.历史账单记录
            Column.onClick(() => {
                //展示图表的信息
            });
            if (!isInitialRender) {
                //2.历史账单记录
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Image.debugLine("viewmodel/item/ItemChart.ets(28:9)");
            Image.width(30);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777225, "type": 10003, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Text.debugLine("viewmodel/item/ItemChart.ets(30:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //2.历史账单记录
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //3.预算剩余
            Column.create({ space: 5 });
            Column.debugLine("viewmodel/item/ItemChart.ets(38:7)");
            __Column__ColumnStyle();
            if (!isInitialRender) {
                //3.预算剩余
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Image.debugLine("viewmodel/item/ItemChart.ets(39:9)");
            Image.width(30);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create({ "id": 16777226, "type": 10003, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" });
            Text.debugLine("viewmodel/item/ItemChart.ets(41:9)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //3.预算剩余
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=ItemChart.js.map