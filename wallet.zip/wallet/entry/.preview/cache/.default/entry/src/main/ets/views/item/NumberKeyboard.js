export default class NumberKeyboard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '.'];
        this.__amount = new SynchedPropertySimpleTwoWayPU(params.amount, this, "amount");
        this.__value = new SynchedPropertySimpleTwoWayPU(params.value, this, "value");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.numbers !== undefined) {
            this.numbers = params.numbers;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__amount.purgeDependencyOnElmtId(rmElmtId);
        this.__value.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__amount.aboutToBeDeleted();
        this.__value.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get amount() {
        return this.__amount.get();
    }
    set amount(newValue) {
        this.__amount.set(newValue);
    }
    get value() {
        return this.__value.get();
    }
    set value(newValue) {
        this.__value.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Grid.create();
            Grid.debugLine("views/item/NumberKeyboard.ets(20:5)");
            Grid.width('100%');
            Grid.height(280);
            Grid.backgroundColor('#F6F7Fb');
            Grid.columnsTemplate('1fr 1fr 1fr');
            Grid.columnsGap(8);
            Grid.rowsGap(8);
            Grid.padding(8);
            Grid.margin({ top: 10 });
            if (!isInitialRender) {
                Grid.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const num = _item;
                {
                    const isLazyCreate = true && (Grid.willUseProxy() === true);
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        GridItem.create(deepRenderFunction, isLazyCreate);
                        GridItem.backgroundColor(Color.White);
                        GridItem.borderRadius(8);
                        GridItem.height(60);
                        GridItem.onClick(() => this.clickNumber(num));
                        GridItem.debugLine("views/item/NumberKeyboard.ets(22:9)");
                        if (!isInitialRender) {
                            GridItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        GridItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(num);
                            Text.debugLine("views/item/NumberKeyboard.ets(23:11)");
                            Text.fontSize(20);
                            Text.fontWeight(900);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        GridItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(num);
                            Text.debugLine("views/item/NumberKeyboard.ets(23:11)");
                            Text.fontSize(20);
                            Text.fontWeight(900);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        GridItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.numbers, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        {
            const isLazyCreate = true && (Grid.willUseProxy() === true);
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                GridItem.create(deepRenderFunction, isLazyCreate);
                GridItem.backgroundColor(Color.White);
                GridItem.borderRadius(8);
                GridItem.height(60);
                GridItem.onClick(() => this.clickDelete());
                GridItem.debugLine("views/item/NumberKeyboard.ets(32:7)");
                if (!isInitialRender) {
                    GridItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                GridItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('删除');
                    Text.debugLine("views/item/NumberKeyboard.ets(33:9)");
                    Text.fontSize(20);
                    Text.fontWeight(900);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                GridItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('删除');
                    Text.debugLine("views/item/NumberKeyboard.ets(33:9)");
                    Text.fontSize(20);
                    Text.fontWeight(900);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                GridItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        Grid.pop();
    }
    //定义输入数字的方法
    clickNumber(num) {
        //1.拼接用户输入的内容
        let val = this.value + num;
        //2.校验输入格式是否正确
        let firstIndex = val.indexOf('.');
        let lastIndex = val.lastIndexOf('.');
        if (firstIndex !== lastIndex || (lastIndex != -1 && lastIndex < val.length - 2)) {
            //非法输入
            return;
        }
        //3.将字符串转为数值
        let amount = this.parseFloat(val);
        //4.保存
        if (amount >= 100000.00) {
            this.amount = 100000.00;
            this.value = val;
        }
        else {
            this.amount = amount;
            this.value = val;
        }
    }
    //删除数字
    clickDelete() {
        if (this.value.length <= 0) {
            this.value = '';
            this.amount = 0;
            return;
        }
        this.value = this.value.substring(0, this.value.length - 1);
        this.amount = this.parseFloat(this.value);
    }
    //转换字符串为数字的方法
    parseFloat(str) {
        if (!str) { //判断输入数值是否存在
            return 0;
        }
        if (str.endsWith('.')) { //判断输入最后是否为小数点
            str = str.substring(0, str.length - 1);
        }
        return parseFloat(str);
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=NumberKeyboard.js.map