export default class ItemConsumeType extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__amount = new SynchedPropertySimpleOneWayPU(params.amount, this, "amount");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
        this.__amount.reset(params.amount);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__amount.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__amount.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get amount() {
        return this.__amount.get();
    }
    set amount(newValue) {
        this.__amount.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("views/item/ItemConsumeType.ets(6:5)");
            Column.margin(10);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //金额展示
            Row.create({ space: 10 });
            Row.debugLine("views/item/ItemConsumeType.ets(8:7)");
            //金额展示
            Row.width('90%');
            //金额展示
            Row.justifyContent(FlexAlign.SpaceEvenly);
            if (!isInitialRender) {
                //金额展示
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('金额');
            Text.debugLine("views/item/ItemConsumeType.ets(9:9)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.amount.toFixed(2));
            Text.debugLine("views/item/ItemConsumeType.ets(12:9)");
            Text.width(100);
            Text.height(50);
            Text.padding(10);
            Text.borderRadius(5);
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.backgroundColor('#ffd8d9de');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //金额展示
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //类型展示
            Row.create({ space: 10 });
            Row.debugLine("views/item/ItemConsumeType.ets(25:7)");
            if (!isInitialRender) {
                //类型展示
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('消费类型');
            Text.debugLine("views/item/ItemConsumeType.ets(26:9)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Select.create([
                { value: '水电', icon: { "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" } },
                { value: '出行', icon: { "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" } },
                { value: '食物', icon: { "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" } },
                { value: '话费', icon: { "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.tallyapplication", "moduleName": "entry" } }
            ]);
            Select.debugLine("views/item/ItemConsumeType.ets(29:9)");
            Select.selected(0);
            Select.value('请选择');
            Select.font({ size: 20, weight: 500 });
            Select.fontColor('#182431');
            Select.selectedOptionFont({ size: 20, weight: 400 });
            Select.optionFont({ size: 20, weight: 400 });
            Select.onSelect((index) => {
                console.info('Select:' + index);
            });
            if (!isInitialRender) {
                Select.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Select.pop();
        //类型展示
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=ItemConsumeType.js.map